package mobSystemTC1;

import static org.testng.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Logs.Log;
import pagesForMob.CompanyPage;
import pagesForMob.HomePage;
import pagesForMob.LandingPage;
import pagesForMob.StartUp;
import pagesForMob.LoginPage;
import pagesForMob.PostPage;
import pagesForMob.ProfilePage;
import pagesForMob.SearchPage;

public class MobTestFlow1 {

	public static Properties configProp, dataProp, elementProp;
	boolean result;
	LandingPage lp = new LandingPage();
	LoginPage lgp = new LoginPage();
	HomePage hp = new HomePage();
	SearchPage sp = new SearchPage();
	CompanyPage cp = new CompanyPage();
	PostPage pp = new PostPage();
	ProfilePage p = new ProfilePage();
	
	@BeforeTest
	public void loadProp()
	{
		//Initializing all properties
		
				configProp = new Properties();
				InputStream configInput = null;
				
				dataProp = new Properties();
				InputStream dataInput = null;
				
				elementProp = new Properties();
				InputStream elementInput = null;

				try {			

					//Reading the property files
					
					configInput = new FileInputStream("Properties\\Mobile\\config.properties");
					configProp.load(configInput);
					
					elementInput = new FileInputStream("Properties\\Mobile\\element.properties");
					elementProp.load(elementInput);
					
					dataInput = new FileInputStream("Properties\\Mobile\\data.properties");
					dataProp.load(dataInput);
					
				} catch (Exception e) {

							e.printStackTrace();
				}
		    	
		    }

	@BeforeClass
	public void InitializeAppium(){

		//Initilaize the App under test
		StartUp.InitializeApp(dataProp.getProperty("apkname"));

		//Initilaize the Device on which App is to be tested
		StartUp.InitializeDevice(dataProp.getProperty("device"), dataProp.getProperty("deviceName"),
				dataProp.getProperty("platformName"), dataProp.getProperty("app"));	
	}
	
	@Test(priority=0)
	public void OpenLinkedIn() {
		// Open LinkedIn App
		StartUp.InitializeDriver(dataProp.getProperty("ip"), dataProp.getProperty("port"));

		// Verify if SignIn link has loaded
		result = lp.VerifySignInLinkLoad(elementProp.getProperty("signinlink"), 20);

		// log the result
		Log.storeResult("openLinkedIn", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=1)
	public void Login() {
		
		//Tap Sign in link
		lp.tapSignIn(elementProp.getProperty("signinlink"));

		// Step 2 : Enter email
		result = lgp.WaitForEmailFieldLoad(elementProp.getProperty("email"), 20);
		lgp.enterEmail(elementProp.getProperty("email"), dataProp.getProperty("email"));

		// Step 3 : Enter password
		lgp.enterPassword(elementProp.getProperty("password"), dataProp.getProperty("password"));

		// Step 4 : Tap Sign in button
		lgp.tapSignIn(elementProp.getProperty("signinbutton"));

		// step 5 : Verify if Search bar has loaded
		result = hp.verifySearchBarLoad(elementProp.getProperty("searchbar"), 20);

		// log the result
		Log.storeResult("Login", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=2)
	public void SearchCompany() {
	
		// Step 1 : Tap on search
		hp.tapSearch(elementProp.getProperty("searchbar"));

		// Step 2 : Enter company name in search bar
		sp.enterCompanyNameToSearch(elementProp.getProperty("searchtoolbar"),dataProp.getProperty("company") + "\n");
		result = sp.verifyCompanyNameEntered(elementProp.getProperty("searchtoolbar"),dataProp.getProperty("company"));

		// step 3 : Verify if company is entered
		sp.tapCompanies(elementProp.getProperty("companies"),elementProp.getProperty("companiesindex"));
		result = sp.verifyCompanyNameLoad(elementProp.getProperty("Artoo"),dataProp.getProperty("company"));

		// log the result
		Log.storeResult("Search Company", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=3)
	public void FollowCompany() {
	
		//Tap on search
		sp.tapContextMenu(elementProp.getProperty("contextmenu"));

		//Hit follow
		sp.tapFollow(elementProp.getProperty("follow"));

		//Verify followed
		sp.wait(5000);
		sp.tapContextMenu(elementProp.getProperty("contextmenu"));
		result = sp.verifyFollowed(elementProp.getProperty("follow"),dataProp.getProperty("followed"));
		sp.dismissPopUp(elementProp.getProperty("framelayout"));

		//log the result
		Log.storeResult("Follow Company", result);

		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=4)
	public void OpenCompanyPage() {
	
		//Tap on company
		sp.tapCompany(elementProp.getProperty("Artoo"));

		//Verify company page open
		result = cp.verifyCompanyPageOpen(elementProp.getProperty("following"), 10);

		//log the result
		Log.storeResult("Load Company Page", result);

		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=5)
	public void UnfollowCompany() {
	
		//Unfollow Company by clicking on 'following'
		cp.tapFollowingUnfollow(elementProp.getProperty("following"));

		//Verify company unfollowed
		result = cp.verifyUnfollowed(elementProp.getProperty("unfollowed"), 10);

		//log the result
		Log.storeResult("UnFollow Company", result);

		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=6)
	public void NavigateToHomePage()
	{
		//Navigate to HomePage
		hp.navigateToPreviousPage();
		hp.navigateToPreviousPage();
		hp.navigateToPreviousPage();
		hp.navigateToPreviousPage();

	}
	
	@Test(priority=7)
	public void Logout() {
		
		//Tap Sign in link
		hp.tapProfileButton(elementProp.getProperty("profile"));
		
		//Tap on profile settings	
		p.verifySettingsButtonLoad(elementProp.getProperty("profilesettings"), 20);
    	p.tapProfileSetting(elementProp.getProperty("profilesettings"));
    	
    	//Tap on communications	
    	p.tapCommunicataions(elementProp.getProperty("communications"),elementProp.getProperty("communicationsclassindex"));
    	
    	//Tap on sign out	
    	p.tapSignOut(elementProp.getProperty("signout"),elementProp.getProperty("signoutclassindex"));
    	
    	//Verify if SignIn link has loaded		
    	result=lp.VerifySignInLinkLoad(elementProp.getProperty("signinlink"), 20);
    	
		//log the result
		Log.storeResult("Logout", result);

		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@AfterClass
	public void displayResult()
	{
		//display the results on the console
		Log.displayResult();
	}

	
	@AfterTest
	public void CloseBrowser()
	{
		//Close the browser
		StartUp.closeApp();
	}
	
}
