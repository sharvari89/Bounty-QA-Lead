package mobSystemTC2;

import static org.testng.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Logs.Log;
import pagesForMob.CompanyPage;
import pagesForMob.HomePage;
import pagesForMob.LandingPage;
import pagesForMob.StartUp;
import pagesForMob.LoginPage;
import pagesForMob.PostPage;
import pagesForMob.ProfilePage;
import pagesForMob.SearchPage;

public class MobTestFlow2 {

	public static Properties configProp, dataProp, elementProp;
	boolean result;
	LandingPage lp = new LandingPage();
	LoginPage lgp = new LoginPage();
	HomePage hp = new HomePage();
	SearchPage sp = new SearchPage();
	CompanyPage cp = new CompanyPage();
	PostPage pp = new PostPage();
	ProfilePage p = new ProfilePage();
	
	@BeforeTest
	public void loadProp()
	{
		//Initializing all properties
		
				configProp = new Properties();
				InputStream configInput = null;
				
				dataProp = new Properties();
				InputStream dataInput = null;
				
				elementProp = new Properties();
				InputStream elementInput = null;

				try {			

					//Reading the property files
					
					configInput = new FileInputStream("Properties\\Mobile\\config.properties");
					configProp.load(configInput);
					
					elementInput = new FileInputStream("Properties\\Mobile\\element.properties");
					elementProp.load(elementInput);
					
					dataInput = new FileInputStream("Properties\\Mobile\\data.properties");
					dataProp.load(dataInput);
					
				} catch (Exception e) {

							e.printStackTrace();
				}
		    	
		    }

	@BeforeClass
	public void setUpAndInitializeAppium(){
		
		//Setup Appium Server
		//StartUp.SetupAppium(dataProp.getProperty("port"), configProp.getProperty("appiumnodepath"),
			//	configProp.getProperty("appiumjspath"));

		//Start Appium Server
		//StartUp.StartAppium();

		//Initilaize the App under test
		StartUp.InitializeApp(dataProp.getProperty("apkname"));

		//Initilaize the Device on which App is to be tested
		StartUp.InitializeDevice(dataProp.getProperty("device"), dataProp.getProperty("deviceName"),
				dataProp.getProperty("platformName"), dataProp.getProperty("app"));	
	}
	
	@Test(priority=0)
	public void OpenLinkedIn() {
		// Open LinkedIn App
		StartUp.InitializeDriver(dataProp.getProperty("ip"), dataProp.getProperty("port"));

		// Verify if SignIn link has loaded
		result = lp.VerifySignInLinkLoad(elementProp.getProperty("signinlink"), 20);

		// log the result
		Log.storeResult("openLinkedIn", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=1)
	public void Login() {
		
		//Tap Sign in link
		lp.tapSignIn(elementProp.getProperty("signinlink"));

		//Enter email
		result = lgp.WaitForEmailFieldLoad(elementProp.getProperty("email"), 20);
		lgp.enterEmail(elementProp.getProperty("email"), dataProp.getProperty("email"));

		//Enter password
		lgp.enterPassword(elementProp.getProperty("password"), dataProp.getProperty("password"));

		//Tap Sign in button
		lgp.tapSignIn(elementProp.getProperty("signinbutton"));

		//Verify if Search bar has loaded
		result = hp.verifySearchBarLoad(elementProp.getProperty("searchbar"), 20);

		// log the result
		Log.storeResult("Login", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=2)
	public void AddPost()
	{
		//Tap on post
		hp.tapPost(elementProp.getProperty("post"));
		
		//Type a post
		pp.enterPost(elementProp.getProperty("posttext"), dataProp.getProperty("postmessage"));
		
		//hit post
		pp.tapPostButton(elementProp.getProperty("postbutton"));
		
		//verify post
		result = hp.verifyPost(elementProp.getProperty("likepost"),20);
	
		// log the result
		Log.storeResult("Add Post", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=3)
	public void LikePost()
	{
		//Tap on like post
		hp.tapLikePost(elementProp.getProperty("likepost"));

		//verify like post
		result = hp.verifyLikePost(elementProp.getProperty("unlikepost"), dataProp.getProperty("like"));

		// log the result
		Log.storeResult("Like Post", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=4)
	public void CommentPost()
	{
		//Tap on comment
		hp.tapComment(elementProp.getProperty("comment"));

		//Type a comment
		pp.typeComment(elementProp.getProperty("commenttype"),dataProp.getProperty("commentpost"));

		//Tap on comment button
		pp.tapCommentButton(elementProp.getProperty("commentpost"));
		
		//verify comment post
		result = pp.verifyComment(elementProp.getProperty("verifycomment"),20);

		// log the result
		Log.storeResult("Comment On The Post", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}

	@Test(priority=5)
	public void EditPost()
	{
		//Tap on context menu
		pp.tapPostContext(elementProp.getProperty("postcontext"));
		
		//Tap on edit option
		pp.tapEditOption(elementProp.getProperty("editpost"),elementProp.getProperty("editpostclassindex"));
		
		//Edit the post
		pp.enterEditPost(elementProp.getProperty("posttext"),dataProp.getProperty("postmessageedit"));
	
		//Tap on edit option
		pp.saveEditPost(elementProp.getProperty("savepost"));
		
		//verify edit post
		result = pp.verifyEditPost(elementProp.getProperty("postmessageedit"),dataProp.getProperty("postmessageedit"));
	
		// log the result
		Log.storeResult("Edit Post", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=6)
	public void DeletePost()
	{
		//Step 1 : Tap on context menu
		pp.tapPostContext(elementProp.getProperty("postcontext"));
		
		//Step 2 : Tap on delete option
		pp.tapDeleteOption(elementProp.getProperty("deletepost"),elementProp.getProperty("deletepostclassindex"));
		
		//Step 3 : Tap on delete Confirmation
		pp.tapDeleteConfirmation(elementProp.getProperty("deletepostconfirm"));
		
		//Step 4 : verify delete post
		result = hp.verifyDeletePost(elementProp.getProperty("profile"),20);
		
		// log the result
		Log.storeResult("Delete Post", result);

		// validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=7)
	public void NavigateToHomePage()
	{
		//Navigate to HomePage
		hp.navigateToPreviousPage();
		hp.navigateToPreviousPage();
		hp.navigateToPreviousPage();
		hp.navigateToPreviousPage();

	}
	
	@Test(priority=8)
	public void Logout() {
	
		//Tap Sign in link
		hp.tapProfileButton(elementProp.getProperty("profile"));
		
		//Tap on profile settings	
		p.verifySettingsButtonLoad(elementProp.getProperty("profilesettings"), 20);
    	p.tapProfileSetting(elementProp.getProperty("profilesettings"));
    	
    	//Tap on communications	
    	p.tapCommunicataions(elementProp.getProperty("communications"),elementProp.getProperty("communicationsclassindex"));
    	
    	//Tap on sign out	
    	p.tapSignOut(elementProp.getProperty("signout"),elementProp.getProperty("signoutclassindex"));
    	
    	//Verify if SignIn link has loaded		
    	result=lp.VerifySignInLinkLoad(elementProp.getProperty("signinlink"), 20);
    	
		//log the result
		Log.storeResult("Logout", result);

		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@AfterClass
	public void displayResult()
	{
		//display the results on the console
		Log.displayResult();
	}

	
	@AfterTest
	public void CloseBrowser()
	{
		//Close the browser
		StartUp.closeApp();
	}
}