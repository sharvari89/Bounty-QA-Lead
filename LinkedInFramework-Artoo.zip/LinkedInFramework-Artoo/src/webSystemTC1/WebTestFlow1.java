package webSystemTC1;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.junit.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Logs.Log;
import pagesForWeb.ArtooCompanyPage;
import pagesForWeb.HomePage;
import pagesForWeb.Launch;
import pagesForWeb.LoginPage;
import pagesForWeb.LogoutPage;
import pagesForWeb.SearchPage;

public class WebTestFlow1 {
	
	public static Properties configProp, dataProp, elementProp;
	boolean result;
	Launch l = new Launch();
	LoginPage lp = new LoginPage();
	HomePage hp = new HomePage();
	SearchPage sp = new SearchPage();
	ArtooCompanyPage acp = new ArtooCompanyPage();
	LogoutPage lo = new LogoutPage();
	
	@BeforeSuite
	public void loadProp()
	{
		//Initializing all properties
		
				configProp = new Properties();
				InputStream configInput = null;
				
				dataProp = new Properties();
				InputStream dataInput = null;
				
				elementProp = new Properties();
				InputStream elementInput = null;

				try {			

					//Reading the property files
					
					configInput = new FileInputStream("Properties\\Web\\config.properties");
					configProp.load(configInput);
					
					elementInput = new FileInputStream("Properties\\Web\\element.properties");
					elementProp.load(elementInput);
					
					dataInput = new FileInputStream("Properties\\Web\\data.properties");
					dataProp.load(dataInput);
					
				} catch (Exception e) {

							e.printStackTrace();
				}
		    	
		    }

	
	@BeforeClass
	public void launch()
	{
		l.launchBrowser(configProp.getProperty("browser"));
	}
	
	@Test(priority=0)
	public void openLinkedIn()
	{
		//Enter url
		lp.openPage(configProp.getProperty("url"));
		
		//Verify if page has loaded		
		result = lp.verifyPageLoad(dataProp.getProperty("launchverification"));
		
		//log the result
		Log.storeResult("openLinkedIn", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
		
	}
	
	@Test(priority=1)
	public void Login()
	{
				//Enter username
				lp.enterUsername(elementProp.getProperty("username"), dataProp.getProperty("username"));
			
				//Enter password
				lp.enterPassword(elementProp.getProperty("password"), dataProp.getProperty("password"));
			
				//Hit signin button
				lp.hitEnterForSignin(elementProp.getProperty("signin"));
				
				//Verify if page has loaded
				result = lp.verifyPageLoad(dataProp.getProperty("loginverification"));
				
				//log the result
				Log.storeResult("Login", result);
				
				//validate the result to mark the test execution status
				assertEquals(result, true);
	}
	
	@Test(priority=2)
	public void SearchCompanies()
	{
				
				//Step 1 : Enter Company Name to search
				hp.search(elementProp.getProperty("search"), dataProp.getProperty("companyname"));
				hp.hitEnterForSearch(elementProp.getProperty("search"));
				
				//Step 2 : Wait for the element to exist
				sp.verifyElementLoad(elementProp.getProperty("companies"), 10);
		
				//step 3: Select the companies 
				sp.selectCompanies(elementProp.getProperty("companies"));
				
				//Step 3 : Verify if companies have loaded
				sp.waitForMilliSeconds(5000);
				result = sp.verifyPageLoad(dataProp.getProperty("companyname"));	
				
				//log the result
				Log.storeResult("search company", result);
				
				//validate the result to mark the test execution status
				assertEquals(result, true);

	}
	@Test(priority=3)
	public void followArtooCompany()
	{
	//Follow Artoo from search page
	sp.followArtooCompany(elementProp.getProperty("follow"));
	
	//Verify if unfollow text is shown
	sp.waitForMilliSeconds(5000);
	result = sp.verifyUnfollowText(elementProp.getProperty("follow"),dataProp.getProperty("unfollow"));
	
	//log the result
	Log.storeResult("follow Company", result);
	
	//validate the result to mark the test execution status
	assertEquals(result, true);
	
	}
	
	@Test(priority=4)
	public void loadCompanyPage()
	{
		//click on the company name to load the page
		sp.selectArtooCompany(elementProp.getProperty("artoocompany"));
		
		//Verify if companies have loaded
		sp.waitForMilliSeconds(5000);
		result = acp.verifyPageLoad(dataProp.getProperty("companyname"));
			
		//log the result
		Log.storeResult("Load Company Page", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=5)
	public void unFollowArtooCompany()
	{
		//unFollow Artoo from search page
		acp.unFollowArtooCompany(elementProp.getProperty("unfollow"));
				
		//Verify if unfollow is successful
		acp.waitForMilliSeconds(5000);
		result = acp.verifyFollowText(elementProp.getProperty("unfollow"),dataProp.getProperty("follow"));
			
		//log the result
		Log.storeResult("Unfollow Company", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=6)
	public void logout()
	{
		// Click user dropdown
		lo.clickUser(elementProp.getProperty("user"));

		// Click Signout
		lo.clickSignout(elementProp.getProperty("signout"));

		// Verify if login page has loaded
		lo.waitForMilliSeconds(5000);
		result = lo.verifyPageLoad(dataProp.getProperty("launchverification"));

		// store result
		Log.storeResult("Logout", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
		
	}
	
	@AfterClass
	public void displayResult()
	{
		Log.displayResult();
	}

	
	@AfterTest
	public void CloseBrowser()
	{
		//Close the browser
		l.closeBrowser();
	}	
	
}
