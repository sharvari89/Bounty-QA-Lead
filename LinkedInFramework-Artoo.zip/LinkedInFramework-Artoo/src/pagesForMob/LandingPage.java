package pagesForMob;

import functions.AppiumFunctions;

public class LandingPage {
	
	//Tap on Gender field
	public boolean VerifySignInLinkLoad(String id, int time){

		return AppiumFunctions.explicitWaitForElement(id, time);
	}
	
	//Tap on sign in link
	public void tapSignIn(String id){

    	AppiumFunctions.clickid(id);
	}
	
	
}
