package pagesForMob;

import functions.AppiumFunctions;

//Page Object Model for Company page

public class StartUp {
	
	//Initialize App
	public static void InitializeApp(String apkName){
			
		AppiumFunctions.initializeApp(apkName); 

	}
	
	//Initialize Device
	public static void InitializeDevice(String device, String deviceName, String platformName, String app){
				
		AppiumFunctions.initializeDevice(device, deviceName, platformName, app); 

	}
	
	//Initialize Driver
	public static void InitializeDriver(String ip, String port){
				
		AppiumFunctions.initializeDriver(ip, port); 

	}
	
	//Close App
	public static void closeApp(){
					
		AppiumFunctions.closeDriver();

	}
	

}
