package webSystemTC2;

import static org.testng.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Logs.Log;
import pagesForWeb.HomePage;
import pagesForWeb.Launch;
import pagesForWeb.LoginPage;
import pagesForWeb.LogoutPage;

public class WebTestFlow2 {

	public static Properties configProp, dataProp, elementProp;
	boolean result;
	Launch l = new Launch();
	LoginPage lp = new LoginPage();
	HomePage hp = new HomePage();
	LogoutPage lo = new LogoutPage();
	
	@BeforeTest
	public void loadProp()
	{
		//Initializing all properties
		
				configProp = new Properties();
				InputStream configInput = null;
				
				dataProp = new Properties();
				InputStream dataInput = null;
				
				elementProp = new Properties();
				InputStream elementInput = null;

				try {			

					//Reading the property files
					
					configInput = new FileInputStream("Properties\\Web\\config.properties");
					configProp.load(configInput);
					
					elementInput = new FileInputStream("Properties\\Web\\element.properties");
					elementProp.load(elementInput);
					
					dataInput = new FileInputStream("Properties\\Web\\data.properties");
					dataProp.load(dataInput);
					
				} catch (Exception e) {

							e.printStackTrace();
				}
		    	
		    }

	
	@BeforeClass
	public void launch()
	{
		l.launchBrowser(configProp.getProperty("browser"));
	}
	
	@Test(priority=0)
	public void openLinkedIn()
	{
		//Enter url
		lp.openPage(configProp.getProperty("url"));
		
		//Verify if page has loaded		
		result = lp.verifyPageLoad(dataProp.getProperty("launchverification"));
		
		//log the result
		Log.storeResult("openLinkedIn", result);
		
		assertEquals(result, true);
	}
	
	@Test(priority=1)
	public void Login()
	{
				//Enter username
				lp.enterUsername(elementProp.getProperty("username"), dataProp.getProperty("username"));
			
				//Enter password
				lp.enterPassword(elementProp.getProperty("password"), dataProp.getProperty("password"));
			
				//Hit signin button
				lp.hitEnterForSignin(elementProp.getProperty("signin"));
				
				//wait for some time for the page to load
				hp.waitForMilliSeconds(5000);
				
				//Verify if page has loaded
				result = lp.verifyPageLoad(dataProp.getProperty("loginverification"));
				
				//log the result
				Log.storeResult("Login", result);
				
				assertEquals(result, true);
	}
	
	@Test(priority=2)
	public void createPost()
	{
		// Click on the post area to add a new post
		hp.clickOnPostArea(elementProp.getProperty("newPost"));
		
		//Enter the text
		hp.enterTheText(elementProp.getProperty("createTextArea"),dataProp.getProperty("postText"));
		
		//click on Post
		hp.hitThePost(elementProp.getProperty("postButton"));
		
		//wait for element to load
		hp.waitforelement(elementProp.getProperty("verifyPost"), 10);
		
		//verify the post is added
		result = hp.verifyPostAdded(elementProp.getProperty("verifyPost"),dataProp.getProperty("postText"));
		
		// log the result
		Log.storeResult("Add new Post", result);
		
		assertEquals(result, true);
	}
	
	@Test(priority=3)
	public void likeThePost()
	{
		// Click on the like button
		hp.clickOnLike(elementProp.getProperty("likeButton"));
		
		//Verify that the post is liked
		result = hp.verifyLikeIsClicked(elementProp.getProperty("likeVal"), dataProp.getProperty("likeText"));
		// log the result
		Log.storeResult("Like successful", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=4)
	public void editThePost()
	{
		// Click on the post options
		hp.clickOnPostOptions(elementProp.getProperty("postOptions"));
				
		//select edit from the options
		hp.selectEdit(elementProp.getProperty("selectEdit"));
		
		//enter the text to edit
		hp.enterTheText(elementProp.getProperty("editTextArea"), dataProp.getProperty("editText"));
		
		//save the edit
		hp.saveTheComment(elementProp.getProperty("saveButton"));
		
		//verify edited Text
		result = hp.verifyEditedText(dataProp.getProperty("editText"), dataProp.getProperty("commentText"));
		
		//log the result
		Log.storeResult("Edit Post",result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
		
	}
	
	@Test(priority=5)
	public void addComment()
	{
		// Click on the comment button
		hp.clickOnCommentButton(elementProp.getProperty("commentButton"));
		
		//Enter the comment text
		hp.enterTheText(elementProp.getProperty("addComment"),dataProp.getProperty("commentText"));
		
		//wait for Post button to appear
		//hp.waitforelement(elementProp.getProperty("postComment"), 10);
		hp.waitForMilliSeconds(5000);
		
		//click on Post Comment
		hp.clickOnPostComment(elementProp.getProperty("postComment"));
		
		//verify comment is added
		result = hp.verifyCommentAdd(dataProp.getProperty("commentText"));
		
		// log the result
		Log.storeResult("Comment Added", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=6)
	public void deletePost()
	{
		// Click on the post options
		hp.clickOnPostOptions(elementProp.getProperty("postOptions"));
		
		//select delete from the options
		hp.selectDelete(elementProp.getProperty("selectDelete"));
		
		//select delete in the confirmation window
		hp.confirmDelete(elementProp.getProperty("deleteYes"));
		
		//verify post deleted
		result = hp.verifyCommentAdd(dataProp.getProperty("commentText"));
		
		//log the result
		Log.storeResult("delete Post", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
	}
	
	@Test(priority=7)
	public void logout()
	{
		// Click user dropdown
		lo.clickUser(elementProp.getProperty("user"));

		// Click Signout
		lo.clickSignout(elementProp.getProperty("signout"));

		// Verify if login page has loaded
		lo.waitForMilliSeconds(5000);
		result = lo.verifyPageLoad(dataProp.getProperty("launchverification"));

		// store result
		Log.storeResult("Logout", result);
		
		//validate the result to mark the test execution status
		assertEquals(result, true);
		
	}
	
	@AfterClass
	public void displayResult()
	{
		Log.displayResult();
	}

	
	@AfterTest
	public void CloseBrowser()
	{
		//Close the browser
		l.closeBrowser();
	}	
	
}
