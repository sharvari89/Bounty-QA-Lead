package pagesForWeb;

import functions.webdriverFunctions;

//Page Object Model for Home page
public class HomePage {
	
	//Search for any item on home page
	public void search(String ObjectID, String text){
	   	
    	webdriverFunctions.type(ObjectID, text);
	}

	//Hit enter for searching in the home page
	public void hitEnterForSearch(String objectID){
	   	
    	webdriverFunctions.hitEnter(objectID);
	}
	
	//Click on the Post Text Area
	public void clickOnPostArea(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);	
	}
	
	//Enter the text to enter on the Post/Text Area
	public void enterTheText(String ObjectID, String text)
	{
		webdriverFunctions.sendKeys(ObjectID, text);
	}
	
	//Hit the Post Button
	public void hitThePost(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	
	//Verify if the Post is Added
	public boolean verifyPostAdded(String ObjectID, String text)
	{
		return webdriverFunctions.verifyTextOfElement(ObjectID, text);
		
	}
	//wait for the element to load
	public void waitforelement(String ObjectID, int time)
	{
		webdriverFunctions.waitForElement(ObjectID, time);
		
	}
	
	//click on the like button
	public void clickOnLike(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
		
	}
	
	//verify if the like button is clicked
	public boolean verifyLikeIsClicked(String ObjectID1, String ObjectID2)
	{
		return webdriverFunctions.verifyElementEnabled(ObjectID1, ObjectID2);
		
	}
	
	//verify if the comment added is displayed
	public boolean verifycommentdisplayed(String ObjectID)
	{
		return webdriverFunctions.verifyElementPresent(ObjectID);
		
	}
	//click on the comment button
	public void clickOnCommentButton(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	
	//click on the post comment after adding the text
	public void clickOnPostComment(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	//verify if the comment is added to the post
	public boolean verifyCommentAdd(String verificationText){
		
	    return webdriverFunctions.verifyText(verificationText);
		}
	//verify the post options
	public void clickOnPostOptions(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	//select delete option
	public void selectDelete(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	//select edit option
	public void selectEdit(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	//confirm delete in the confirmation window
	public void confirmDelete(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	//verify if the post is deleted
	public boolean verifyPostdelete(String verificationText){
		
	    boolean res= webdriverFunctions.verifyText(verificationText);
	    if(res)
	    	return false;
	    return true;
	    
		}
	
	//verify the edited text
	public boolean verifyEditedText(String verificationText1, String verificationText2)
	{
		webdriverFunctions.verifyText(verificationText1+verificationText2);
		return true;
	}
	//save the comment added
	public void saveTheComment(String ObjectID)
	{
		webdriverFunctions.clickXpath(ObjectID);
	}
	
	//Wait for the element to appear
		public void waitForMilliSeconds(long time){
			
			webdriverFunctions.waitPeriod(time);
		}
}
