package pagesForWeb;

import functions.webdriverFunctions;

public class LoginPage {
	
	//Open the Login page
	public void openPage(String url){
	   	
    	webdriverFunctions.openPage(url);
	}
	
	public boolean verifyPageLoad(String verificationText){
		
    return webdriverFunctions.verifyText(verificationText);
	}
	
	//Enter Username in the username field
		public void enterUsername(String objectID, String value){
		   	
	    	webdriverFunctions.sendKeys(objectID, value);
		}
		
		//Enter password in the password field
		public void enterPassword(String objectID, String value){
		   	
	    	webdriverFunctions.sendKeys(objectID, value);
		}

		//Hit Enter for sign in
		public void hitEnterForSignin(String objectID){
		   	
	    	webdriverFunctions.hitEnter(objectID);
		}
			
}
