package pagesForWeb;

import functions.webdriverFunctions;

//Launch and close browser

public class Launch {
	
	//Launch Browser
	public void launchBrowser(String browser){
		
    	webdriverFunctions.launchBrowser(browser); 

	}
	
	//Close Browser
	public void closeBrowser(){
		
    	webdriverFunctions.closeBrowser();

	}
	

}
