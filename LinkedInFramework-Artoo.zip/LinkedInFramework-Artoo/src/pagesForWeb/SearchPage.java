package pagesForWeb;

import functions.webdriverFunctions;

public class SearchPage {
	
	//Search for a particular text
		public void search(String ObjectID, String text){
		   	
	    	webdriverFunctions.type(ObjectID, text);
		}

		//Hit enter to search the keyword
		public void hitEnterForSearch(String objectID){
		   	
	    	webdriverFunctions.hitEnter(objectID);
		}
		
		//Select companies matching the search
		public void selectCompanies(String objectID){
		   	
	    	webdriverFunctions.clickXpath(objectID);
		}
		
		//Select Artoo company in search
		public void selectArtooCompany(String objectID){
		   	
	    	webdriverFunctions.clickXpath(objectID);
		}
		
		//Verify if search page has loaded
		public boolean verifyPageLoad(String verificationText){
			
	    	return webdriverFunctions.verifyText(verificationText);
		}
		
		//Verify if element on search page has loaded
		public void verifyElementLoad(String objectID, int waitTime){
			
	    	webdriverFunctions.waitForElement(objectID, waitTime);
		}
		
		//Wait for a time period
		public void waitForMilliSeconds(long time){
			
			webdriverFunctions.waitPeriod(time);
		}
		
		//Hit Follow to follow Artoo company
		public void followArtooCompany(String objectID){
			
			webdriverFunctions.clickXpath(objectID);
		}
		
		//Verify if unfollow text is visible
		public boolean verifyUnfollowText(String ObjectID, String verificationText){
			
	    	return webdriverFunctions.verifyTextOfElement(ObjectID, verificationText);
		}
		

}
